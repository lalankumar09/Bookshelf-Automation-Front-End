import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-search-member',
  templateUrl: './search-member.component.html',
  styleUrls: ['./search-member.component.css']
})
export class SearchMemberComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
