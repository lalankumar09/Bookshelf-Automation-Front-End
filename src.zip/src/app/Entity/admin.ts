export class Admin {
    constructor(
      public   adminId:number=null,
      public   adminName:string=null,
      public   adminPassword:string=null,
      public   adminDob:string=null,
      public   adminAddress:string=null,
      public   adminEmail:string=null
    ) {}
}
