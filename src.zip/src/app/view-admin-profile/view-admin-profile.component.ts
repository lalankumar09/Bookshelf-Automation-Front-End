import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-view-admin-profile',
  templateUrl: './view-admin-profile.component.html',
  styleUrls: ['./view-admin-profile.component.css']
})
export class ViewAdminProfileComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
